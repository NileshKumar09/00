﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CIMS2.Entities;
using CIMS2.Exceptions;
using CIMS2.BAL;
using System.Data;

namespace CIMS2.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }



        private void BtnAddCar_Click(object sender, RoutedEventArgs e)
        {
            AddCar();
            GetCars();
        }

        private void BtnDeleteCar_Click(object sender, RoutedEventArgs e)
        {
            DeleteCar();
        }

        private void BtnSearchCar_Click(object sender, RoutedEventArgs e)
        {
            SearchCar();
        }

        private void BtnUpdateCar_Click(object sender, RoutedEventArgs e)
        {
            UpdateCar();
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }
        private void AddCar()
        {
            try
            {
                int manufacturerId;

                string model;

                int type;

                string engine;


                int transmission;

                int mileage;

                int seats;

                string airbags;
                int bhp;

                string bootSpace;

                string price;

                //
                bool carAdded;
                //
                manufacturerId = Convert.ToInt32(cmbManufacturerId.SelectedValue);
                model = txtModel.Text;
                type = Convert.ToInt32(cmbType.SelectedValue);
                engine = txtEngine.Text;
                bhp = Convert.ToInt32(txtBHP.Text);
                transmission = Convert.ToInt32(cmbTransmissionId.SelectedValue);
                mileage = Convert.ToInt32(txtMileage.Text);
                seats = Convert.ToInt32(txtSeats.Text);
                airbags = txtAirbags.Text;
                bootSpace = (txtBootSpace.Text);
                price = (txtPrice.Text);
                //
                Car car = new Car
                {
                    ManufacturerId = manufacturerId,
                    Model = model,
                    Type = type,
                    Engine = engine,
                    BHP = bhp,
                    Transmission = transmission,
                    Mileage = mileage,
                    Seat = seats,
                    AirBagDetails = airbags,
                    BootSpace = bootSpace,
                    Price = price
                };
                CarBAL carBal = new CarBAL();
                carAdded = carBal.AddCarBAL(car);
                if (carAdded == true)
                {
                    MessageBox.Show("Car record added successfully.");
                }
                else
                {
                    MessageBox.Show("Car record couldn't be added.");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
            
        private void DeleteCar()
        {
            try
            {
                int id;
                //
                bool CarDeleted;
                //
                id = Convert.ToInt32(txtId.Text);
                //
                CarBAL bal = new CarBAL();
                CarDeleted = bal.DeleteCarBAL(id);
                if (CarDeleted == true)
                {
                    MessageBox.Show("Car record deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Car record couldn't be deleted.");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetMan()
        {
            CarBAL bal = new CarBAL();
            try
            {
                DataTable designationList = bal.GetManufacturerBAL();
                cmbManufacturerId.ItemsSource = designationList.DefaultView;
                cmbManufacturerId.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbManufacturerId.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTypeId()
        {
            CarBAL bal = new CarBAL();
            try
            {
                DataTable designationList = bal.GetCarTypeBAL();
                cmbType.ItemsSource = designationList.DefaultView;
                cmbType.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbType.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTrans()
        {
            CarBAL bal = new CarBAL();
            try
            {
                DataTable designationList = bal.GetCarTransmissionBAL();
                cmbTransmissionId.ItemsSource = designationList.DefaultView;
                cmbTransmissionId.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbTransmissionId.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetCars()   //displays service requests
        {
            try
            {
                CarBAL bal = new CarBAL();
                List<Car> cars = bal.GetAllRequest();
                if (cars != null)
                {
                    dgCarDetails.ItemsSource = cars;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (CarException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        private void UpdateCar()
        {

            try
            {
                int id;
                int manufacturerName;

                string model;

                int type;

                string engine;

                int bhp;

                int transmission;

                int mileage;

                int seats;

                string airbags;

                string bootSpace;

                string price;

                //
                bool carUpdated;
                //
                //
                id = Convert.ToInt32(txtId.Text);
                manufacturerName = Convert.ToInt32(cmbManufacturerId.SelectedValue);
                model = txtModel.Text;
                type = Convert.ToInt32(cmbType.SelectedValue);
                engine = txtEngine.Text;
                bhp = Convert.ToInt32(txtBHP.Text);
                transmission = Convert.ToInt32(cmbTransmissionId.SelectedValue);
                mileage = Convert.ToInt32(txtMileage.Text);
                seats = Convert.ToInt32(txtSeats.Text);
                airbags = txtAirbags.Text;
                bootSpace = (txtBootSpace.Text);
                price = (txtPrice.Text);
                //
                Car car = new Car
                {
                    Id = id,
                    ManufacturerId = manufacturerName,
                    Model = model,
                    Type = type,
                    Engine = engine,
                    BHP = bhp,
                    Transmission = transmission,
                    Mileage = mileage,
                    Seat = seats,
                    AirBagDetails = airbags,
                    BootSpace = bootSpace,
                    Price = price
                };
                CarBAL carBal = new CarBAL();
                carUpdated = carBal.UpdateCarBAL(car);
                if (carUpdated == true)
                {
                    MessageBox.Show("Car record updated successfully.");
                }
                else
                {
                    MessageBox.Show("Car record couldn't be updated.");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void SearchCar()
        {
            try
            {
                int id;
                //
                Car objcar;
                //
                id = Convert.ToInt32(txtId.Text);
                //
                CarBAL carBal = new CarBAL();
                objcar = carBal.SearchCarBAL(id);
                if (objcar != null)
                {
                    cmbManufacturerId.SelectedValue = objcar.ManufacturerId;
                    txtModel.Text = objcar.Model;
                    txtMileage.Text = objcar.Mileage.ToString();
                    txtPrice.Text = objcar.Price;
                    txtSeats.Text = objcar.Seat.ToString();
                    txtEngine.Text = objcar.Engine;
                    txtBootSpace.Text = objcar.BootSpace;
                    txtBHP.Text = objcar.BHP.ToString();
                    txtAirbags.Text = objcar.AirBagDetails;
                    cmbTransmissionId.SelectedValue = objcar.Transmission;
                    cmbType.SelectedValue = objcar.Type;

                }
                else
                {
                    MessageBox.Show("Car record couldn't be found.");

                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Clear()
        {
            cmbManufacturerId.SelectedIndex = -1;
            cmbTransmissionId.SelectedIndex = -1;
            cmbType.SelectedIndex = -1;
            txtModel.Clear();
            dgCarDetails.DataContext = null;
            txtMileage.Clear();
            txtPrice.Clear();
            txtSeats.Clear();
            txtEngine.Clear();
            txtBootSpace.Clear();
            txtBHP.Clear();
            txtAirbags.Clear();
            txtId.Clear();
  }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetCars();
            GetMan();
            GetTypeId();
            GetTrans();
        }
    }
}


            