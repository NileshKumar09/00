﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CIMS2.Entities;
using CIMS2.Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace CIMS2.DAL
{
    public class CarDAL
    {
        public bool AddCarDetails(Car objCar)
        {
            bool carAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CIMS2.ConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009519].[InsertCar]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                SqlParameter objSqlParam_Id = new SqlParameter("@Id", objCar.Id);
                SqlParameter objSqlParam_ManufacturerId = new SqlParameter("@ManufacturerId", objCar.ManufacturerId);
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", objCar.Model);
                SqlParameter objSqlParam_Type = new SqlParameter("@TypeId", objCar.Type);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", objCar.Engine);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", objCar.BHP);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@TransmissionId", objCar.Transmission);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", objCar.Mileage);
                SqlParameter objSqlParam_Seat = new SqlParameter("@Seat", objCar.Seat);
                SqlParameter objSqlParam_AirbagDetails = new SqlParameter("@AirBagDetails", objCar.AirBagDetails);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", objCar.BootSpace);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", objCar.Price);

                objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_ManufacturerId);
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seat);
                objCom.Parameters.Add(objSqlParam_AirbagDetails);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);

                objCon.Open();
                objCom.ExecuteNonQuery();
                carAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return carAdded;

        }
        public bool UpdateCarDAL(Car objCar)
        {
            bool carUpdated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CIMS2.ConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009519].UpdateCar", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objsqlParam_Id = new SqlParameter("@Id", objCar.Id);
                SqlParameter objSqlParam_ManufacturerId = new SqlParameter("@ManufacturerId", objCar.ManufacturerId);
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", objCar.Model);
                SqlParameter objSqlParam_Type = new SqlParameter("@TypeId", objCar.Type);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", objCar.Engine);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", objCar.BHP);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@TransmissionId", objCar.Transmission);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", objCar.Mileage);
                SqlParameter objSqlParam_Seat = new SqlParameter("@Seat", objCar.Seat);
                SqlParameter objSqlParam_AirbagDetails = new SqlParameter("@AirBagDetails", objCar.AirBagDetails);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", objCar.BootSpace);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", objCar.Price);


                //
                objCon.Open();
                objCom.Parameters.Add(objsqlParam_Id);
                objCom.Parameters.Add(objSqlParam_ManufacturerId);
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seat);
                objCom.Parameters.Add(objSqlParam_AirbagDetails);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);
                objCom.ExecuteNonQuery();
                carUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return carUpdated;
        }
        public bool DeleteCarDAL(int id)
        {
            bool carDeleted = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CIMS2.ConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009519].DeleteCar", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@ID", id);
                //
                objCom.Parameters.Add(objSqlParam_Id);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                carDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return carDeleted;
        }
        public Car SearchCarDAL(int id)
        {
            Car objCar = null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CIMS2.ConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009519].SearchCar", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@ID", SqlDbType.Int);
                SqlParameter objSqlParam_ManufacturerId = new SqlParameter("@ManufacturerId", SqlDbType.VarChar,50);
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Type = new SqlParameter("@TypeId", SqlDbType.Int);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", SqlDbType.Int);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@TransmissionId", SqlDbType.Int);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", SqlDbType.Int);
                SqlParameter objSqlParam_Seat = new SqlParameter("@Seat", SqlDbType.Int);
                SqlParameter objSqlParam_AirbagDetails = new SqlParameter("@AirBagDetails", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", SqlDbType.VarChar, 50);
                //
                objSqlParam_Id.Direction = ParameterDirection.Input;
                objSqlParam_ManufacturerId.Direction = ParameterDirection.Output;
                objSqlParam_Model.Direction = ParameterDirection.Output;
                objSqlParam_Type.Direction = ParameterDirection.Output;
                objSqlParam_Engine.Direction = ParameterDirection.Output;
                objSqlParam_BHP.Direction = ParameterDirection.Output;
                objSqlParam_Transmission.Direction = ParameterDirection.Output;
                objSqlParam_Mileage.Direction = ParameterDirection.Output;
                objSqlParam_Seat.Direction = ParameterDirection.Output;
                objSqlParam_AirbagDetails.Direction = ParameterDirection.Output;
                objSqlParam_BootSpace.Direction = ParameterDirection.Output;
                objSqlParam_Price.Direction = ParameterDirection.Output;
                //
                objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_ManufacturerId);
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seat);
                objCom.Parameters.Add(objSqlParam_AirbagDetails);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);
                //
                //
                objSqlParam_Id.Value = id;
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                objCar = new Car();
                objCar.Id = id;
                objCar.ManufacturerId = Convert.ToInt32(objSqlParam_ManufacturerId.Value) ;
                objCar.Model = (objSqlParam_Model.Value) as string;
                objCar.TypeId = Convert.ToInt32(objSqlParam_Type.Value);
                objCar.TransmissionId = Convert.ToInt32(objSqlParam_Transmission.Value);
                objCar.Mileage = Convert.ToInt32(objSqlParam_Mileage.Value);
                objCar.BHP = Convert.ToInt32(objSqlParam_BHP.Value);
                objCar.Engine = (objSqlParam_Engine.Value) as string;
                objCar.AirBagDetails = (objSqlParam_AirbagDetails.Value) as string;
                objCar.BootSpace = (objSqlParam_BootSpace.Value) as string;
                objCar.Price = (objSqlParam_Price.Value) as string;
                objCar.Seat = Convert.ToInt32(objSqlParam_Seat.Value);
            }
            catch (SqlException objSqlEx)
            {
                throw new CarException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objCar;
        }


        public DataTable GetManufacturer()
        {
            DataTable manufacturerList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CIMS2.ConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009519].GetManufacturer", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                manufacturerList = new DataTable();
                manufacturerList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new CarException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return manufacturerList;
        }
        public DataTable GetCarType()
        {
            DataTable CarTypeList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CIMS2.ConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009519].GetCarType", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                CarTypeList = new DataTable();
                CarTypeList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new CarException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarTypeList;
        }
        public DataTable GetCarTransmission()
        {
            DataTable CarTransmissionList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CIMS2.ConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009519].GetTransmission", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                CarTransmissionList = new DataTable();
                CarTransmissionList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new CarException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarTransmissionList;
        }
        public List<Car> GetAllCarDetails()
        {
            List<Car> cars = new List<Car>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CIMS2.ConnectionString"].ConnectionString);  //connection with database is established
                SqlCommand objCom = new SqlCommand("[46009519].GetAllCars", objCon);   //retrieves data into stored procedure
                objCom.CommandType = CommandType.StoredProcedure;

                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Car car1 = new Car();
                    car1.Id = Convert.ToInt32(objDR[0]);
                    car1.Model = (objDR[1]) as string;
                    car1.ManufacturerId = Convert.ToInt32(objDR[2]);
                    car1.TypeId = Convert.ToInt32(objDR[3]);
                    car1.Engine = (objDR[4]) as string;
                    car1.BHP = Convert.ToInt32(objDR[5]);
                    car1.TransmissionId = Convert.ToInt32(objDR[6]);
                    car1.Mileage = Convert.ToInt32(objDR[7]);
                    car1.Seat = Convert.ToInt32(objDR[8]);
                    car1.AirBagDetails = (objDR[9]) as string;
                    car1.BootSpace = (objDR[10]) as string;
                    car1.Price = (objDR[11]) as string;
                    cars.Add(car1);
                }
            }

            catch (SqlException objSqlEx)
            {
                throw new CarException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return cars;
        }

    }
}


