﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIMS2.Exceptions
{
    public class CarException:ApplicationException
    {
        public CarException() : base() { }

        public CarException(string message) : base(message) { }

        public CarException(string message, Exception innerException) : base(message, innerException) { }
    }
}
