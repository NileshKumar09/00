﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CIMS2.DAL;
using CIMS2.Entities;
using CIMS2.Exceptions;
using System.Data;
using System.Text.RegularExpressions;

namespace CIMS2.BAL
{
    public class CarBAL
    {
        public static List<Car> Carlist = new List<Car>();
        public static bool Validate(Car car)
        {
            bool validate = true;
            try
            {
                if (!(Regex.IsMatch(car.Engine, @"^\d\.\dL$")))
                {
                    validate = false;
                    throw new CarException("Engine name should have 4 characters with 1st and 3rd character should be a number and 2nd should be a'.'and last would be a 'L'");

                }
                if (!(Regex.IsMatch(car.BHP.ToString(), @"^[0-9]{1,3}$")))
                {
                    validate = false;
                    throw new CarException("BHP should be a number");
                }
                
                if (!(Regex.IsMatch(car.Mileage.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    throw new CarException("Mileage should be a number");
                }
                if (!(Regex.IsMatch(car.Seat.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    throw new CarException("seats should be a number");
                }
                if (!(Regex.IsMatch(car.AirBagDetails, @"^[A-Za-z]{1,}$")))
                {
                    validate = false;
                    throw new CarException("Airbags details should be a string");
                }
                if (!(Regex.IsMatch(car.BootSpace.ToString(), @"^[0-9]{1,3}$")))
                {
                    validate = false;
                    throw new CarException("Bootspace should be a number with 3 digits");
                }
                if (!(Regex.IsMatch(car.Price.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    throw new CarException("Price should be a number");
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
            return validate;

        }

        public bool AddCarBAL(Car car)
        {
            bool CarAdded = false;
            try
            {
                CarDAL carDal = new CarDAL();
                CarAdded = carDal.AddCarDetails(car);

            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CarAdded;
        }
        public bool DeleteCarBAL(int carId)
        {
            bool carDeleted = false;
            try
            {
                if (carId > 0)
                {
                    CarDAL carDal = new CarDAL();
                    carDeleted = carDal.DeleteCarDAL(carId);
                }
                else
                {
                    throw new CarException(" Id must be greater than 0.");
                }
            }
            catch (CarException Cex)
            {
                throw Cex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carDeleted;
        }
        public bool UpdateCarBAL(Car car)
        {
            bool carUpdated = false;
            try
            {

                {
                    CarDAL carDal = new CarDAL();
                    carUpdated = carDal.UpdateCarDAL(car);

                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carUpdated;
        }
        public Car SearchCarBAL(int carId)
        {
            Car objCar = null;
            try
            {
                if (carId > 0)
                {
                    CarDAL carDal = new CarDAL();
                    objCar = carDal.SearchCarDAL(carId);
                }
                else
                {
                    throw new CarException(" Id must be greater than 0.");
                }
            }
            catch (CarException Eex)
            {
                throw Eex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objCar;
        }

        public DataTable GetManufacturerBAL()
        {
            DataTable ManufacturerList;
            try
            {
                CarDAL carDAL = new CarDAL();
                ManufacturerList = carDAL.GetManufacturer();
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ManufacturerList;
        }
        public DataTable GetCarTypeBAL()
        {
            DataTable CarTypeList;
            try
            {
                CarDAL carDAL = new CarDAL();
                CarTypeList = carDAL.GetCarType(); ;
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CarTypeList;
        }
        public DataTable GetCarTransmissionBAL()
        {
            DataTable CarTransmissionList;
            try
            {
                CarDAL carDAL = new CarDAL();
                CarTransmissionList = carDAL.GetCarTransmission();
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CarTransmissionList;
        }
        public List<Car> GetAllRequest()
        {
            List<Car> carList = null;
            try
            {
                CarDAL DAL = new CarDAL();
                carList = DAL.GetAllCarDetails();   //getallrequest in dal is accessed
            }
            catch (CarException Eex)
            {
                throw Eex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carList;
        }
    }
}
